<?php
// Data Mahasiswa
$mahasiswa = [
    ["nama" => "Fathir", "tugas" => 90, "uts" => 95, "uas" => 85],
    ["nama" => "Hasbi", "tugas" => 80, "uts" => 85, "uas" => 80],
    ["nama" => "Ramadhan", "tugas" => 90, "uts" => 88, "uas" => 92]
];

function hitungNilaiAkhir($tugas, $uts, $uas) {
    return ($tugas * 0.3) + ($uts * 0.3) + ($uas * 0.4);
}

function getPredikat($nilai) {
    if ($nilai >= 85) return "A";
    elseif ($nilai >= 80) return "B+";
    elseif ($nilai >= 70) return "B";
    elseif ($nilai >= 60) return "C+";
    elseif ($nilai >= 50) return "C";
    elseif ($nilai >= 40) return "D";
    else return "E";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nilai Mahasiswa</title>
    <style>
        table { border-collapse: collapse; width: 60%; margin: 20px auto; }
        th, td { border: 1px solid #999; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
        h2 { text-align: center; }
    </style>
</head>
<body>
    <h2>Data Nilai Mahasiswa</h2>
    <table>
        <tr>
            <th>Nama</th>
            <th>Tugas</th>
            <th>UTS</th>
            <th>UAS</th>
            <th>Nilai Akhir</th>
            <th>Predikat</th>
        </tr>
        <?php foreach ($mahasiswa as $mhs): 
            $akhir = hitungNilaiAkhir($mhs['tugas'], $mhs['uts'], $mhs['uas']);
            $predikat = getPredikat($akhir);
        ?>
        <tr>
            <td><?= $mhs['nama'] ?></td>
            <td><?= $mhs['tugas'] ?></td>
            <td><?= $mhs['uts'] ?></td>
            <td><?= $mhs['uas'] ?></td>
            <td><?= number_format($akhir, 2) ?></td>
            <td><?= $predikat ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>